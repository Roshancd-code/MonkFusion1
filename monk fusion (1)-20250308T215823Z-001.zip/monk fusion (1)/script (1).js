// Dark Mode Toggle
const darkModeToggle = document.getElementById('dark-mode-toggle');
const body = document.body;

// Check for saved dark mode preference in localStorage
if (localStorage.getItem('dark-mode') === 'enabled') {
  body.classList.add('dark-mode');
}

// Toggle dark mode
darkModeToggle.addEventListener('click', () => {
  body.classList.toggle('dark-mode');

  // Save user preference in localStorage
  if (body.classList.contains('dark-mode')) {
    localStorage.setItem('dark-mode', 'enabled');
  } else {
    localStorage.setItem('dark-mode', 'disabled');
  }
});


// Cart Functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Function to update the cart count in the header
function updateCartCount() {
  const cartCount = document.getElementById('cart-count');
  if (cartCount) {
    cartCount.textContent = cart.length;
  }
}

// Function to add a product to the cart
function addToCart(product) {
  cart.push(product);
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
}

// Function to render the cart items on the cart page
function renderCart() {
  const cartList = document.getElementById('cart-list');
  const cartTotal = document.getElementById('cart-total');
  let total = 0;

  if (cartList && cartTotal) {
    cartList.innerHTML = ''; // Clear the cart list
    cart.forEach((item, index) => {
      const cartItem = document.createElement('div');
      cartItem.className = 'cart-item';
      cartItem.innerHTML = `
        <p>${item.name} - $${item.price}</p>
        <button class="btn remove-from-cart" data-index="${index}">Remove</button>
      `;
      cartList.appendChild(cartItem);
      total += parseFloat(item.price);
    });

    cartTotal.textContent = total.toFixed(2); // Update the total price
  }
}

// Add to Cart Buttons
document.querySelectorAll('.add-to-cart').forEach(button => {
  button.addEventListener('click', () => {
    const product = {
      id: button.dataset.id,
      name: button.dataset.name,
      price: button.dataset.price,
    };
    addToCart(product);
  });
});

// Remove from Cart Buttons
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('remove-from-cart')) {
    const index = e.target.dataset.index;
    cart.splice(index, 1); // Remove the item from the cart
    localStorage.setItem('cart', JSON.stringify(cart)); // Update localStorage
    renderCart(); // Re-render the cart
    updateCartCount(); // Update the cart count in the header
  }
});

// Render Cart on Cart Page
if (window.location.pathname.includes('cart.html')) {
  renderCart();
}

// Initialize Cart Count
updateCartCount();

// Stripe Payment Integration
if (window.location.pathname.includes('checkout.html')) {
  const stripe = Stripe('your-publishable-key-here'); // Replace with your Stripe publishable key
  const elements = stripe.elements();
  const cardElement = elements.create('card');
  cardElement.mount('#card-element');

  const form = document.getElementById('payment-form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Collect shipping details
    const shippingDetails = {
      name: document.getElementById('shipping-name').value,
      address: document.getElementById('shipping-address').value,
      city: document.getElementById('shipping-city').value,
      state: document.getElementById('shipping-state').value,
      zip: document.getElementById('shipping-zip').value,
      country: document.getElementById('shipping-country').value,
    };

    // Validate shipping details
    if (
      !shippingDetails.name ||
      !shippingDetails.address ||
      !shippingDetails.city ||
      !shippingDetails.state ||
      !shippingDetails.zip ||
      !shippingDetails.country
    ) {
      alert('Please fill in all shipping details.');
      return;
    }

    // Create payment method
    const { error, paymentMethod } = await stripe.createPaymentMethod({
      type: 'card',
      card: cardElement,
    });

    if (error) {
      document.getElementById('card-errors').textContent = error.message;
    } else {
      // Send paymentMethod.id and shipping details to your server
      alert('Payment successful! Shipping details collected.');
      localStorage.removeItem('cart'); // Clear cart after payment
      window.location.href = 'index.html'; // Redirect to homepage
    }
  });
}